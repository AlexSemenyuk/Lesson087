package org.itstep.dependency;

public class RequiredClass {

}
